export function query(input: unknown, pages: unknown[], database: {searchFts(query: string): Array<{slug: string; title: string; rank: number}>}): unknown;
